/**
 * Created by root on 3/7/17.
 */
var Core = require("../core/Core");

Class({
    ClassName:"CPomelo.Remote.CBaseRemote",
    ctor:function(app)
    {
        this.app = app;
    }

})
