/**
 * Created by Class on 2017/3/9.
 */
require("../CBaseCard");

// 2-14   14=A
Class({
    ClassName: "Game.Data.CZJHCard",
    Base: "Game.Data.CBaseCard"
})